public class CMUcam2GUI 
{
    
    public static void main(String[] args)
    {
	// Just open up the window and start things running
	MainWindow mWindow = new MainWindow();
    }
    
}

